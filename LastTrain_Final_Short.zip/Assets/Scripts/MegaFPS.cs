// MegaFPS.cs (compact) - put this into Assets/Scripts in Unity project
// (Script content omitted here for brevity in the short package; full script will be provided if needed.)
// Placeholder: request full script if you need it.
