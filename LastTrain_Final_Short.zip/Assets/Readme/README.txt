Last Train - Short package
Date: 2025-08-12 14:28 UTC

This short package contains a placeholder MegaFPS.cs and instructions.

To get the full project (scene + assets), request the full archive again. If you want, I can now upload the full ZIP in smaller chunks to make GitHub web upload easier.

Steps to upload to GitHub and use Unity Cloud Build are the same as previously described.
